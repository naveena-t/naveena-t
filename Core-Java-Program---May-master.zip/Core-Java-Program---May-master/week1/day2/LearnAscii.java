package week1.day2;

public class LearnAscii {
public static void main(String[] args) {
	int value = '7';
	System.out.println(value);
}
}
