package week1.day2;

import week1.day1.Mobile;

public class AccessMobile {
public static void main(String[] args) {
	Mobile myMobile = new Mobile();
	System.out.println(myMobile.model);
}
}
