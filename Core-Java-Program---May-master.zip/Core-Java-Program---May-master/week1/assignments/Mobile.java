package week1.assignments;

public class Mobile {
public String brand = "BlackBerry";
private long imei = 987654321098765L;
int ramSize = 8;

public void makeCall() {
	System.out.println("Calling");
}
private void takePhoto() {
	System.out.println("Taking photo");
}
void sendSMS() {
	System.out.println("Text sent");
}





}
