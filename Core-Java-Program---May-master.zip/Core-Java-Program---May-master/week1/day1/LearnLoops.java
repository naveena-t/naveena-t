package week1.day1;

public class LearnLoops {
public static void main(String[] args) {
//	for(iterator intialization; condition; incre/decrem)
for(int i=1;i<=10;++i) {
	System.out.println(i);
}
int i =5;
do {
	System.out.println(i++);
}while(i<10);





		/*
		 * while(condition) { Condition is true Block }
		 */




}
}
