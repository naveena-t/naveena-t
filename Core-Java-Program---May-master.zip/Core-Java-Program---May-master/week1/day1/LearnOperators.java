package week1.day1;

public class LearnOperators {
public static void main(String[] args) {
	int a = 5;
	
	System.out.println(a/=5);
		/*
			System.out.println(++a);
		 * post incremental -> ; System.out.println(a++); System.out.println(a);
		 */
}
}
