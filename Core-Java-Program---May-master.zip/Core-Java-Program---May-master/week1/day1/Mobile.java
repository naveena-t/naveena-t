package week1.day1;

public class Mobile {
private String mobileBrand = "Apple";
public int model = 8;

long imei = 998876651234L;
boolean isCharged= true;
public static void main(String[] args) {
	int a =5;
	Mobile obj = new Mobile();
	System.out.println(obj.mobileBrand);
}
}
