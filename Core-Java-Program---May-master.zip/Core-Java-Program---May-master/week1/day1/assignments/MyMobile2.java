package week1.day1.assignments;

import week1.assignments.Mobile;

public class MyMobile2 {
public static void main(String[] args) {
	String name = "Balaji";
	Mobile obj = new Mobile();
	System.out.println(obj.brand);
	obj.makeCall();
}
}
