package week1.day1;

public class MyMobile {
public static void main(String[] args) {
	// className obj = new Constructor();
	Mobile object = new Mobile();
	System.out.println(object.imei);
	
}
}
