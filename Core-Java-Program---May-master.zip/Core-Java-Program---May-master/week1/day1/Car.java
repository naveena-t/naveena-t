package week1.day1;

public class Car {
	// Datatype variableName = value;

	public static void main(String[] args) {
		System.out.println("Welcome to Testleaf");
		String carName = "Wagon R";
		System.out.println("Car name: "+carName);
		short seatingCapacity = 4;
		System.out.println("Seating Capacity: "+seatingCapacity);
		long chasisNumber = 12345678910111213L;
		float fuelTankCapacity = 26.87F;
		double engineCapacity = 1123.234567811231123444;
		char varient = 'P';
		boolean isPunctured = false;

	}

}
