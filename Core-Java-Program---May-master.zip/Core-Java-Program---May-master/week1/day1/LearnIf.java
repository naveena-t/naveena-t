package week1.day1;

public class LearnIf {
public static void main(String[] args) {
	int a = 5, b = 11;
	System.out.println(a>b);
	
	
	
	if (a>b) {
		// True block
		System.out.println("a is greater");
	}
	else {
		// false block
		System.out.println("b is greater");
	}
	
}
}
