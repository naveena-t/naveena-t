package week4.day2;

public class LearnDebugging {
public static void main(String[] args) {
	int[] array = {1,3,5,7,9,11};
	for (int i = 0; i < array.length; i++) {
		System.out.println(array[i]);
	}
}
}
