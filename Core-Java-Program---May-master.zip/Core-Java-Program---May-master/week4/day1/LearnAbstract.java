package week4.day1;

public abstract class LearnAbstract {
public void print() {
	System.out.println("Printed");
}
public abstract void display();
}
