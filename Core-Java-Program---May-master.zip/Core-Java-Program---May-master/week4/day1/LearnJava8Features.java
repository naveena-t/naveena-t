package week4.day1;

public interface LearnJava8Features {
public void sendKeys() ;
public static void click() {
	System.out.println("Clicked");
}
}
