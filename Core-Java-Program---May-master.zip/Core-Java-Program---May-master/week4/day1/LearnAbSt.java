package week4.day1;

public abstract class LearnAbSt{
public LearnAbSt() {
	
}
public static void  run() {
	
}
protected abstract void meow();
}
