package week4.day1;

public class SubClass extends LearnAbstract{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
		SubClass obj = new SubClass();
		obj.display();
		obj.print();
	}

}
