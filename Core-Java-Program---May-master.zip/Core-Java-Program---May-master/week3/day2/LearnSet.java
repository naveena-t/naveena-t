package week3.day2;

import java.util.LinkedHashSet;
import java.util.Set;

public class LearnSet {
public static void main(String[] args) {
	Set<String> obj = new LinkedHashSet<String>();
	obj.add("Zara");
	obj.add("Harry");
	obj.add("Bob");
	obj.add("Dobby");
	obj.add("Emma");
	System.out.println(obj);
}
}
