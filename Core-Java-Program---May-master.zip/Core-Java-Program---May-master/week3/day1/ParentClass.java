package week3.day1;

public final class ParentClass {
	public ParentClass() {
		System.out.println("Get Parent Asserts");
	}
	public void getHouse() {
		System.out.println("My House - Parent");
	}

	public void getCar() {
		System.out.println("My Car - Parent");
	}
	public final void getBankBalance() {
		System.out.println("My Bank Balance - Parent");
	}
}
