package week3.day1;

public class LearnDt {
public static void main(String[] args) {
	Object[] array = {1,2,3,5,6,"balaji",true,'a',9.8877};
	int a = 5;
	double c = a;
	System.out.println(c);
	System.out.println(a+"");
	Integer b = 5;
	double value = b.doubleValue();
	System.out.println(value);
}
}
