package week3.day1;

public class ChildClass extends ParentClass{
	public ChildClass() {
		super();
	}
public void getHouse() {
	System.out.println("My House - Child");
}
public void getParentHouse() {
	super.getHouse();
}
public void getBankBalance() {
	
}
}
