package week3.day1;

public class LearnFinal {
	   final int a = 5;
public static void main(String[] args) {
	LearnFinal obj = new LearnFinal();
	obj.a+=5;
}
}
