package week3.day1;

public class MyClass {
public static void main(String[] args) {
	ChildClass cls = new ChildClass();
	cls.getCar();
	cls.getHouse();
	cls.getParentHouse();
}
}
