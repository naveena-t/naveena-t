package week2.day1;

public class Bajaj extends Auto{

}
