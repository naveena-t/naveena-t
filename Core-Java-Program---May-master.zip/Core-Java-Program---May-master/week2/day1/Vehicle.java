package week2.day1;

public class Vehicle extends Commute{
public void acclerate(){
	System.out.println(carName);
	System.out.println("Speed up the vehicle");
}
public void applyBrake() {
	System.out.println("Slow down the vehicle");
}
public void soundHorn() {
	System.out.println("Make some noise");
}
}
