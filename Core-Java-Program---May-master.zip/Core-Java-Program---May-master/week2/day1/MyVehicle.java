package week2.day1;

public class MyVehicle {
public static void main(String[] args) {
	BMW myCar = new BMW();
	myCar.acclerate();
	myCar.applyBrake();
	myCar.soundHorn();
	myCar.sunRoof();
}
}
