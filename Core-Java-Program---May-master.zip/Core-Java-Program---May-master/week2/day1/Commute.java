package week2.day1;

public class Commute {
protected static String carName = "Bugati";
int fuelCapacity = 34;
}
