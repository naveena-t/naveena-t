package week2.day1;

public class NestedLoops {
public static void main(String[] args) {
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 3; j++) {
			System.out.println(i+","+j);
		}
	}
}
}
