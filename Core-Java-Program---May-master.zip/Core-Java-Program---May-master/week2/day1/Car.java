package week2.day1;

public class Car extends Vehicle{

}
