package week2.day1;

public class MyFamily {
public static void main(String[] args) {
	Father myFather = new Father();
	System.out.println(myFather.apartment);
	myFather.givingNothing();
	System.out.println(myFather.house);
	myFather.giveAway();
}
}
