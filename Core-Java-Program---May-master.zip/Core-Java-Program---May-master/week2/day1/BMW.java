package week2.day1;

public class BMW extends Car{

	public void sunRoof() {
		System.out.println("Open sunroof");
	}
}
