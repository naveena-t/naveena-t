package week2.day1;

public class GrandFather {
public String house = "2400 sqft villa @ Adayar";
public void giveAway() {
	System.out.println("Everything is for Balaji");
}
}
