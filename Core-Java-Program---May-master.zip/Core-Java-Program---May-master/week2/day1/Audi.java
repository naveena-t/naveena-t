package week2.day1;

public class Audi extends Car{

}
