package week2.day1;

public class Auto extends Vehicle{

}
