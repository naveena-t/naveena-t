package week2.day1;

public class Father extends GrandFather{
public String apartment = "Citadine 13 th floor apartment";
public void givingNothing() {
	System.out.println(Commute.carName);
	System.out.println("He will give nothing");
}
}
