package week2.day2;

public class Car extends Vehicle{

}
