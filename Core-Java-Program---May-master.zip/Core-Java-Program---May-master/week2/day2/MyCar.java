package week2.day2;

import week2.day1.Commute;

public class MyCar extends Commute{
public static void main(String[] args) {
	BMW car = new BMW();
	car.applyBrake();
	Car myCar = new Car();
	myCar.applyBrake();
	System.out.println(carName);
}
}
