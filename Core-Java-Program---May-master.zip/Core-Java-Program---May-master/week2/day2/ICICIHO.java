package week2.day2;

public interface ICICIHO {
public void provideGoldLoans();
public void holidays();
public void provideHomeLoan();
}
