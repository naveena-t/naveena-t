package week2.day2;

public class MyCalculator {
public static void main(String[] args) {
	Calculator calc = new Calculator(5,10);
	calc.add();
}
}
