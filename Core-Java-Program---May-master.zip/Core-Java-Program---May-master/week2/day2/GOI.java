package week2.day2;

public interface GOI {
public void reimburseLPGSubsidary();
}
