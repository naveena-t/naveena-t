package week2.day2;

public class Vehicle {
public void applyBrake() {
	System.out.println("Apply Normal Break");
}
public void acclerate() {
	System.out.println("Move forward");
}
}
