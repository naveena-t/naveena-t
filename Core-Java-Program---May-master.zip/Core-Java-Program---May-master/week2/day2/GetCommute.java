package week2.day2;

import week2.day1.Commute;

public class GetCommute extends Commute{
void commute(){
	System.out.println(carName);
}
}
