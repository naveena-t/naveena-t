package week2.day2;

public class BMW extends Car{
	public void applyBrake() {
		System.out.println("Apply ABS Break");
	}
}
