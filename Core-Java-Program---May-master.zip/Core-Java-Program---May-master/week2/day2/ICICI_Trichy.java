package week2.day2;

public class ICICI_Trichy {
public static void main(String[] args) {
	RBI myBranch = new ICICI();
	RBI.lendLoanstotheBanks();

}
}
