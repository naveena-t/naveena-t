package week8.day1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class LearnThrows {

	public static void main(String[] args) throws FileNotFoundException  {
		
		FileInputStream fis = new FileInputStream("./data/test.xlsx");		
				

	}

}
