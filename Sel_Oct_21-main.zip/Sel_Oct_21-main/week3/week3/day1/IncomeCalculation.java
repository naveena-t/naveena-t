package week3.day1;

public interface IncomeCalculation {
	
	  void calcGrossIncome();
	  
	  void removeDeductions();
	  
	  void replicatedMthd();
	

}
