package week3.day1;

public class Auto extends Vehicle {
	
	int wheelAuto =3;

}
