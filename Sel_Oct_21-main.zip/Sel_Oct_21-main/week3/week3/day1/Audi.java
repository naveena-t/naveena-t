package week3.day1;

public class Audi extends Car {
	
    @Override   // optional
	public void shiftGear() {
		System.out.println(" Audi applies an automatic gear");
	}
    
    
    
	

	
}
