package week3.day1;

public class Vehicle {

	public void driveVehicle() {
		// TODO Auto-generated method stub
		System.out.println(" Drivong the vehicle");
	}

	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println(" Accelerate");
	}

	public void applyBrake() {
		// TODO Auto-generated method stub
		System.out.println(" apply the brake");
	}

	public void fillFuel() {
		// TODO Auto-generated method stub
		System.out.println(" fill the fuel");
	}

	public void shiftGear() {
		// TODO Auto-generated method stub
		System.out.println(" Manuall Shift the gear");
	}

}
