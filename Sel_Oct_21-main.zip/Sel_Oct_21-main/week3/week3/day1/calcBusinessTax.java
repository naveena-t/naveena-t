package week3.day1;

public class calcBusinessTax implements TaxCalculation {

	public void calcDeductions(String name, double HRA, double LTA) {
		// TODO Auto-generated method stub
		
	}

	public void calcGrossIncome(String name, double netIncome, double deductions) {
		// TODO Auto-generated method stub
		
	}

	public void replicatedMthd() {
		// TODO Auto-generated method stub
		
	}

}
