package week3.day1;

public class Car extends Vehicle{
	
	int wheelCar = 4;

	public void closeDoor() {
		System.out.println(" Closes the door");
	}

	public void enableAirbag() {
		System.out.println("airbag enabled");
	}

}
