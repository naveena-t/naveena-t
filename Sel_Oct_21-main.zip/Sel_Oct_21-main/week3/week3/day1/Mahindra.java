package week3.day1;

public class Mahindra extends Auto{

}
