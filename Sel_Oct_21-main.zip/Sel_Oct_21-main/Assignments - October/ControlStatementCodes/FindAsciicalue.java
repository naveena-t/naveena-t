package javabasiccodes;

public class FindAsciicalue {

 public static void main(String[] args) {
 char c='A';
 int ascii=c;
 System.out.println("The ascii value of given input is :" +ascii);
	}

}
