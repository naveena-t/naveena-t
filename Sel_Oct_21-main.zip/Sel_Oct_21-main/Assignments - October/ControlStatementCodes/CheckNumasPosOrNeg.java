package javabasiccodes;

public class CheckNumasPosOrNeg {

	public static void main(String[] args) {
int number=10;
if(number>0)
{
	System.out.println("The given number " +number +" is positive");
}else if(number<0)
{
	System.out.println("The given number " +number +" is Negative");
}else

	System.out.println("The given number " +number +" is neither positive or negative");

	}

}
