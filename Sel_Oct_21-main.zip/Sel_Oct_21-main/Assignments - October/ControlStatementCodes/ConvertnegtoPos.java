package javabasiccodes;

public class ConvertnegtoPos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int number=-40;
if(number<0)
{
	System.out.println("Converted negative number is " +number*-1);
}
else System.out.println(number+ "The number is positive" );
	}

}
