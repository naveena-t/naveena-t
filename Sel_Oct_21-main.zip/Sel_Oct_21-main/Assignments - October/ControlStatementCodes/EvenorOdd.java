package javabasiccodes;

public class EvenorOdd {

	public static void main(String[] args) {
int number=25;
if(number%2==0)
{
	System.out.println("The given number is even" );
}else {
	System.out.println("The given number is odd");
}
	}

}
