package week1.day1;

public class LearnWhile {

	public static void main(String[] args) {
		
		int number = 3;
		while(number != 8) {
			System.out.println(" Number is :" + number);
			number++;
		}
	}

}
