package week1.day1;

public class LearnReturn {

	public static void main(String[] args) {
		
		boolean value = false;
		
		if (value == true) {
			System.out.println(" true");
			return;
		}
		// out of the method
		System.out.println(" Other codes for execution");
			

	}

}
