package week1.day1;

public class LearnDataTypesVariables {

	public static void main(String[] args) {
		// camel case
		float size = 14.5f; // declaration; initilization
		String shape = "Rectangle";
		String IMEI = "273738328283Ihge";
		char brandName = 'S';
		int resolution = 1080;
		byte weight = 100;
		boolean isTouchScreen = true;
		short costMobile = 30000;
	
		System.out.println("size");
		System.out.println(size);
		// concatenation operator +
		System.out.println("The size of the mobile is " + size);
		System.out.println("Shape is:" + shape);
		System.out.println(brandName);
		
		 
		
		

	}

}
