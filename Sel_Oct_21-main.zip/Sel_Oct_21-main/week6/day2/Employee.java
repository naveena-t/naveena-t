package week6.day2;

public class Employee {

	public static void main(String[] args) {
		//ClassName.staticMethodName()
		EmployeeInfo.staticMethod();

	}

}
