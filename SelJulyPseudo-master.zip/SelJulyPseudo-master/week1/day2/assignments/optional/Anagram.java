package week1.day2.assignments.optional;

public class Anagram {
	
	/*
	 * Pseudo Code
	  
	 *Declare a String 
				String text1 = "stops";
	 *Declare another String
				String text2 = "potss"; 
	 * a) Check length of the strings are same then (Use A Condition)
	 * b) Convert both Strings in to characters
	 * c) Sort Both the arrays
	 * d) Check both the arrays has same value
	 * 
	 */



}