package week3.day2.classroom;

public class ErailSort {

	public static void main(String[] args) throws InterruptedException {
//		Launch the browser
		
//		Launch the URL - https://erail.in/
		
//		Uncheck the check box - sort on date
		
//		clear and type in the source station 
		
//		clear and type in the destination station
		
//		Find all the train names using xpath and store it in a list
		
//		Use Java Collections sort to sort it and then print it
		
	}

}