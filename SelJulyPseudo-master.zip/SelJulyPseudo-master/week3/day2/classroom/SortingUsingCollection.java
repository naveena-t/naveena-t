package week3.day2.classroom;

public class SortingUsingCollection {

	public static void main(String[] args) {

		String[] input = {"HCL","Wipro","Aspire Systems","CTS"};
//		Declare a String array and add the Strings values as (HCL, Wipro,  Aspire Systems, CTS)		

//		get the length of the array		

//		sort the array			

//		Iterate it in the reverse order

//		print the array
		
//		Required Output: Wipro, HCL , CTS, Aspire Systems

	}

}
