package week3.day2.classroom;

public class VerifyTrainNamesAreUnique {

	public static void main(String[] args) throws InterruptedException {
		
//		Set the system property and Launch the URL
		
//		Click the 'sort on date' checkbox
		
//		clear the existing text from station text field
		
//		type "ms"in the from station text field
		
//		tab in the from station text field
		
//		clear the existing text in the to station text field
		
//		type "mdu" in the to station text field
		
//		tab in the to station text field
		
//		Add a java sleep for 2 seconds
		
//		Store all the train names in a list
		
//		Get the size of list
		
//		Add the list into a new Set
		
//		Get the size of set

//		Compare the Size of list and Set to verify the names are unique

	}

}
