package week2.day1.Assignments;

public class FindAccount {

	public static void main(String[] args) {
		/*
		 * //Pseudo Code
		 * 
		 * 1. Launch URL "http://leaftaps.com/opentaps/control/login"
		 * 
		 * 2. Enter UserName and Password Using Id Locator
		 * 
		 * 3. Click on Login Button using Class Locator
		 * 
		 * 4. Click on CRM/SFA Link
		 * 
		 * 5. Click on Accounts Button
		 * 
		 * 6. Click on Find Accounts
		 * 
		 * 7. Enter AccountName as "Credit Limited Account" 
		 *  
		 * 8. Click on Find Accounts using xpath Locator
		 * 
		 * 9. Click on the edit Button
		 * 
		 * 10. Get the Text of Account Name and verify 
		 *  
		 * 11. Get the Text of Description
		 * 
		 * 12. Get the title of the page and verify it.
		 */

	}

}
