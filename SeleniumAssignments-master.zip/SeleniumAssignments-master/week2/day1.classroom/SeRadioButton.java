package seleniumCR;

public class SeRadioButton {
	
	/*
	 * //Pseudo Code
	 * 
	 * 1. Launch URL "http://www.leafground.com/"
	 * 
	 * 2. Click on RadioButton
	 * 
	 * 3. Click the RadioButton Option for Are you enjoying the classes?
	 * 
	 * 4. Get the text for default selected radio button
	 * 
	 * 5.  Get the text for ,Select your age group (Only if choice wasn't selected) if not 
	      Select your age Group and get the text.
	 * 
	 * 
	 */

}
