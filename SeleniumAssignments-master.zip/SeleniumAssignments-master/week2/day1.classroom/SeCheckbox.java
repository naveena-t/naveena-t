package seleniumCR;

public class SeCheckbox {
	
	/*
	 * //Pseudo Code
	 * 
	 * 1. Launch URL "http://www.leafground.com/"
	 * 
	 * 2. Click on CheckBox
	 * 
	 * 3. Select the Options for Select the languages that you know?
	 * 
	 * 4. Confirm Selenium is Checked 
	 * 
	 * 5.  DeSelect IamSelected CheckBox
	 * 
	 * 6. Select all the checkBoxes Available in (Select all below checkBoxes)
	 */

}
