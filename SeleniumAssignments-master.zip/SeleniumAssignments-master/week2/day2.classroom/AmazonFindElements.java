package week2.day2.Classroom;

public class AmazonFindElements {
//	Title - To practice findElements (multiple elements)
	public static void main(String[] args) {
		
		//Launch the browser
		
		//Load the URL - "https://www.amazon.in/"
		
		//Search in the search box as 'USI punching bag'
		
		//check 'Eligible for Pay On Delivery' checkbox
		
		//find all the bag names and store it in a list
		
		//print the size
		
		//Iterate it over an array
		
			//Print all the names
		
		//Close the browser
		
	}

}
