package day2;

public class PractiseXpath {

	public static void main(String[] args) {

		/*
		**No need to write Selenium script - Just find these elements in the DOM using only XPaths
		
		Try all the xpaths that you've learnt (basic, text-based, axes..)

		1. Launch the URL
		
		2. Enter the username based on its label
		
		3. Enter the password based on its label
		
		4. Click Login
		
		5. Click on CRMSFA link
		
		6. Click on Leads link
		
		7. Click on Merge Leads link
		
		8. Click the first img icon
		
		9. Select the first resulting lead
		
		10. Click the second img icon
		
		11. Select the second resulting lead
		
		12. Click on Merge Lead (submit) button
		
		13. Get the company name text based on its label
		
		*/


	}

}
