package seleniumCR;

public class Myntra {

	public static void main(String[] args) {
		
		/*
		 * //Pseudo Code
		 * 
		 * 1. Launch URL "https://www.myntra.com/"
		 * 
		 * 2. Maximize the browser
		 * 
		 * 3. Search 'Shirt' in the Search bar [find it using Xpath]
		 * 
		 * 4. Check U.S Polo Assn under brand
		 *  
		 * 5. Sort by 'what's new'
		 * 
		 * 5. Get all the prices of the shirts available and store it in a List
		 * 
		 * 6. Print all the prices of the Shirts
		 */
		
		
	}

}
