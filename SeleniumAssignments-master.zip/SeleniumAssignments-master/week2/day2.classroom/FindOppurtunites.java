package seleniumCR;

public class FindOppurtunites {

	public static void main(String[] args) {
		/*
		 * //Pseudo Code
		 * 
		 * 1. Launch URL "http://leaftaps.com/opentaps/control/login"
		 * 
		 * 2. Enter UserName and Password Using Xpath Locator
		 * 
		 * 3. Click on Login Button using Xpath Locator
		 * 
		 * 4. Click on CRM/SFA Link
		 * 
		 * 5. Click on Oppurtunites Button
		 * 
		 * 6. Click on Find Oppurtunites using Xpath Locator
		 * 
		 * 7. Get the List of Oppurtunites available in Oppurtunity id usinf Xpath Locator
		 * 
		 * 8. Get the Title of the Page and verify it.
		 */

	}

}
