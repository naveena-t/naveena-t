Assingment : Map
Write a Java Program to Find the Occurance of Each Character in the given String : "welcome to Selenium automation"

PseudoCode:
1. Create a String with your name as value
2. Convert the string into a char array		
3. Create an empty Map<Character,Integer>
4. Iterate over the array
5. Save the Character as key and iterator(i) as value
6. Check whether the Map contains the Character
7. If it contains then increment the key (+1)
8. Add the character in the map & set the value as 1
9. Print the Map				