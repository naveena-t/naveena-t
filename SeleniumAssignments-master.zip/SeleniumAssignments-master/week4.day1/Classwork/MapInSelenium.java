

//	1) Set the property
		
//	2) Initiate ChromeDriver class

//	3) Launch the URL - https://erail.in/
		
//	4) Maximize the browser
		
//	5) Add implicityWait
		
//	6) Clear and type in the from station
		
//	7) Clear and type in the to station
		
//	8) Uncheck the 'Sort on Date' checkbox		
		
//	9) Declare a Map
		
//	10) Store the table in a web element
		
//	11) Get all the rows and store it in a List
		
//	12) Iterate the rows and store all the columns in a List
		
//		13) Check and get the values that start with 'S'

//		14) If the condition satisfies add it into the map as key & 	value

//		15) Print those values by iterating the map
		