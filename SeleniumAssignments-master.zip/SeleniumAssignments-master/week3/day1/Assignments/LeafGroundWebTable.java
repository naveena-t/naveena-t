package week3.day1.Assignments;

public class LeafGroundWebTable {

	public static void main(String[] args) {

		/*
		 * URL - http://www.leafground.com/pages/table.html
		 * 
		 * 1) Set the property for chromedriver and initialize the driver
		 * 
		 * 2) launch the url
		 * 
		 * 3) Get the table and store it as a webelement
		 * 
		 * 4) Find the number of rows based on its tag name and store it in a list
		 * 
		 * 5) Find the number of cols based on its tag name and store it in a list
		 * 
		 * 6) Print the size of the rows
		 * 
		 * 7) Print the size of the cols
		 * 
		 * 8) Get the progress value of 'Learn to interact with Elements' and store it in a variable
		 * 
		 * 9) Print the text of the variable
		 * 
		 * 10) Find the vital task for the least completed progress and check the box
		 * 
		 * 
		 */		

	}

}
