package week3.day1.Classroom;

public class SortingUsingCollection {

	public static void main(String[] args) {

	// Declare a String array and add the Strings values as (Google,Microsoft,TestLeaf,Maverick)		

	// get the length of the array		

	// sort the array			

	// Iterate it in the reverse order

	// print the array
		
	// Required Output: Wipro, HCL , CTS, Aspire Systems

	}

}
