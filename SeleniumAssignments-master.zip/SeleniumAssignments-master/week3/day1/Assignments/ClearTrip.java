package week3.day1.Assignments;

public class ClearTrip {

	public static void main(String[] args) {

		/*
		 * URL - https://www.cleartrip.com/

		1) Launch chrome and load URL, Add implicitwait

		2) Click Round trip

		3) Enter From city (Chennai) and TAB

		4) Enter To city (New York) and TAB

		5) Click Depart On (text box) 

		6) Select current date as Depart date

		7) Click Return On (text box) 

		8) Select tomorrow's date as return date

		9) Select Adults (as 2)

		10) Select Children (as 1)

		11) Select Infant (as 1)

		12) Click More Options (use id as locator)

		13) Select Premium Economy as Class of Travel

		14) Enter Preferred Airline as Emirates and TAB

		15) Click Search Flights 

		 */		




	}

}
