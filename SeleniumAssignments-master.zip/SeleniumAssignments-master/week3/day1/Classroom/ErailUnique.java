package week3.day1.Classroom;

public class ErailUnique {

	public static void main(String[] args) throws InterruptedException {
		
//		Set the system property and Launch the URL
		
//		Click the 'sort on date' checkbox
		
//		clear and type in the from station text field
		
//		clear and type in the to station text field
		
//		Add a java sleep for 2 seconds
		
//		Store all the train names in a list
		
//		Get the size of it
		
//		Add the list into a new Set
		
//		And print the size of it

	}

}
