package week3.day2.Classroom;

public class IRCTC {

	public static void main(String[] args) {

		/*

		1) Launch chrome and load URL - https://www.irctc.co.in/
		
		2) Click on FLIGHTS link
		
		3) Print the title of the Flights window
		
		4) Close the train search window (first window)
		
		5) Get the toll free (1800 110 139) from Flights window and print

		 */

	}

}
