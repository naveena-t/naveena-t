package week3.day2.Classroom;

public class HandleAlert {

	public static void main(String[] args) {

		/*
		1) Launch the URL - https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt

		2) Maximize the browser

		3) Set the TimeOuts 

		4) Switch in to the frame

		5) Click on the Try it button

		6) Enter your name in the Alert's text box

		7) Accept the Alet

		8) Verify your name in the text and print it

		 */

	}

}
