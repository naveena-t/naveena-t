package week2.day1;

public class Wrappers {
public static void main(String[] args) {
	int a = 5;
	System.out.println((float)a);
	Integer b = 5;
	System.out.println(b.floatValue());
	int value = Integer.parseInt("47");
	System.out.println(value+3);
	
}
}
