package week2.day2;

public class Vehicle {
public void applyBrake() {
	System.out.println("Normal Brake applied");
}
public void soundHorn() {
	System.out.println("Horn Used");
}
}
