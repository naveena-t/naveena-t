package week2.day2;

public class LearnMain {
public static void main(String[] args) {
	System.out.println("Hello world");
}
}
