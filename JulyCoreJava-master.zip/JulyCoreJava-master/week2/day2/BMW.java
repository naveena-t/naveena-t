package week2.day2;

public class BMW extends Car {

	public void openSunroof() {
		System.out.println("Sun roofed Opened");
	}
	@Override
	public void applyBrake() {
		System.out.println("ABS Brake applied");
	}
	public void opendoor() {
		
	}

	
}
