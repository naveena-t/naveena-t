package week2.day2;

public class MyCar {
public static void main(String[] args) {
	Car mycar = new Car();
	mycar.applyBrake();
	
	BMW myCar = new BMW();
	myCar.applyBrake();
}
/*
 * Auto myauto = new Auto(); myauto.turnOnMeter(); myauto.applyBrake();
 * myauto.soundHorn();
 */
}
