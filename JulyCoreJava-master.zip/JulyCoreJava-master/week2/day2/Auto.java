package week2.day2;

public class Auto extends Vehicle{

	public void turnOnMeter() {
		System.out.println("Meter Started");
	}
}
