package week2.day2;

public class Car extends Vehicle{

	public void switchOnAC() {
		System.out.println("AC switched on");
	}
	public static void opendoor() {
		System.out.println("Door opened");
	}
}
