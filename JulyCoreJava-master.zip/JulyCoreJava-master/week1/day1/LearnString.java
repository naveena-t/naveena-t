package week1.day1;

public class LearnString {
public static void main(String[] args) {
	String str = "Balaji";
}
}
