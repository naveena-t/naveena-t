package week1.day1;

public class LearnDatatypes {
	// How to declare a variable?
	// data-type variable-name = value ;
	private short age = 26;
	int landLineNumber = 24325678;
	long mobileNumber = 9876543200L;
	float currentBankBalance = 500819987987890123333333333333333333.12983812738172839182123123123F;
	double expBankBalance = 98765432.9876543;
	char initial = 'C';
	boolean hadBreakFast = false;
	
	
}
