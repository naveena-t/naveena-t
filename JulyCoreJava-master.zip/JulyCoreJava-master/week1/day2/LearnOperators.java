package week1.day2;

public class LearnOperators {
public static void main(String[] args) {
	int a = 7;
	System.out.println(a++); // a = 7
	System.out.println(a);// a = 7 + 1
	System.out.println(a--); // a = 8;
	System.out.println(a); // a = 8-1
	int b = 8;
	System.out.println(++b);
	System.out.println(--b);
	// a++; -> a = a+1;
	
	// Short Hand operator
	int c = 5;
//	c = c + 2;
	c %= 2; // -> c = c+2
	System.out.println(c);
	
	// Relational or compartive Operator
	/*
	<  -> Less than
	>  -> Greater than
	<= -> Less than or equal to
	>= -> Greater than or equal to
	== -> Equality
	!= -> Not equal
	*/
	
	// Logical Operator
		/*
		 * && -> Logical AND 
		 * || -> Logical OR 
		 * ! -> Logical NOT
		 */
	
	
	
	
	
	
}
}
