package week1.day2;

public class LearnControl_For {
	public static void main(String[] args) {
		/*
		 * for(initialisation;condition;Increment/Decrement) { }
		 */
		/*	for(short i = 1 ; i <= 10 ; i++ )	
	System.out.println("Good Morning");
}*/
		/*
		 * for(int i = 1 ; i <= 10 ; i++) { System.out.println(i); }
		 */
		for(int i = 10 ; i >= 1 ; i--) {
			System.out.println(i);
		}
	}
}