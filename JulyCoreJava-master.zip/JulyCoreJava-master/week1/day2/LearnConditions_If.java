package week1.day2;

public class LearnConditions_If {
public static void main(String[] args) {
	int a = 5, b = 10;
	if(a>b) {
		// If the condition is true - True block
		System.out.println("A is Greater");
	}
	else {
		// If the condition is false - False block
		System.out.println("B is Greater");
	}
	
	System.out.println("Process ended");
}
}
