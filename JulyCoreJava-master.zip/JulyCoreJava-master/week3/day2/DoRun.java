package week3.day2;

public class DoRun extends LearnAbstract{

	@Override
	public void run() {
		
		
	}

}
