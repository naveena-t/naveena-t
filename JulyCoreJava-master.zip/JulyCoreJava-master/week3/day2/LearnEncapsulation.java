package week3.day2;

public class LearnEncapsulation {
private int pin = 1111;
int getPin() {
	return pin;
}
void setPin(int newpin) {
	pin = newpin;
}
}
