package week3.day2;

public abstract class LearnAbstract {

	public void walk() {
		
	}
	
	public abstract void run();
}
